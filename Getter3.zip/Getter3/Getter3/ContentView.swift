//
//  ContentView.swift
//  Getter3
//
//  Created by Rohin Joshi on 4/5/23.
//

import SwiftUI

struct ContentView: View {
    @State private var tabSelected: Tab = .clipboard

    init() {
        UITabBar.appearance().isHidden = true
    }

    var body: some View {
        ZStack {
            VStack {
                TabView(selection: $tabSelected) {
                    ForEach(Tab.allCases, id: \.self) { tab in
                        getView(for: tab)
                            .tag(tab)
                    }
                }

                VStack {
                    Spacer()
                    CustomTabBar(selectedTab: $tabSelected)
                }
            }
        }
    }

    private func getView(for tab: Tab) -> some View {
        switch tab {
        case .calendar:
            return AnyView(NewEventView())
        case .clipboard:
            return AnyView(ListView())
        case .person:
            return AnyView(Text("Person"))
        }
    }
}



    //ListView()
//                        HStack {
//                            Image(systemName: tab.rawValue)
//                            Text("\(tab.rawValue.capitalized)")
//                                .bold()
//
//                                .animation(nil, value: tabSelected)
//                        }
//                        .tag(tab)


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
