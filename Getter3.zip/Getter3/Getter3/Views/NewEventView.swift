//
//  NewEventView.swift
//  Getter3
//
//  Created by Rohin Joshi on 4/5/23.
//

import SwiftUI

struct NewEventView: View {
    var body: some View {
        Text("new event view")
    }
}

struct NewEventView_Previews: PreviewProvider {
    static var previews: some View {
        NewEventView()
    }
}
