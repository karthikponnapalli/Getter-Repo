//
//  NewEventView.swift
//  Getter
//
//  Created by Rohin Joshi on 4/12/23.
//

import SwiftUI

struct NewEventView: View {
    @State var newEventString: String = ""
    @State var notesEventString: String = ""
    @State var selectedStartDate: Date = Date()
    @State var selectedEndDate: Date = Date()
    
    @Environment(\.dismiss) var dismiss
    
    enum AssignmentType {
        case assignment, quiz, test, project
    }
    
    enum PriorityType {
        case urgent, ongoing, upcoming, finished
    }
    
    @State private var assignmentType:AssignmentType = .assignment
    @State private var priorityType:PriorityType = .urgent
    
    var body: some View {
        
        VStack{
            //heading
            HStack{
                //                Text(K.GetterName.getterName)
                //                    .font(.system(size:43, weight: .bold))
                //                    .padding(.leading, -175)
            }
            ScrollView{
                
                VStack{
                    ZStack{
                        Text("New Item")
                            .font(.system(size:23, weight:.bold))
                        //                                .padding(.leading, -175)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(10)
                        
                        Button("Cancel", role: .destructive){
                            dismiss()
                        }
                        
                        
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        .padding(20)
                        .font(.system(size:18, weight:.bold))
                    }
                    
                    
                    VStack{
                        
                        TextField("New Event", text: $newEventString)
                            .padding()
                            .background(Color.gray.opacity(0.23).cornerRadius(10))
                    }
                    .padding(.horizontal)
                    
                    
                    VStack{
                        TextField("Notes", text: $notesEventString)
                            .padding()
                            .background(Color.gray.opacity(0.23).cornerRadius(10))
                    }
                    .padding(.horizontal)
                    
                    HStack{
                        Text("Assignment Type")
                            .padding(.horizontal)
                        
                        Spacer()
                        
                        Picker("Assignment Type", selection: $assignmentType){
                            
                            Text("Assignment").tag(AssignmentType.assignment)
                            Text("Quiz").tag(AssignmentType.quiz)
                            Text("Test").tag(AssignmentType.test)
                            Text("Project").tag(AssignmentType.project)
                            
                            
                        }
                        
                    }
                    
                    HStack{
                        Text("Priority")
                            .padding(.horizontal)
                        
                        Spacer()
                        
                        Picker("Priority", selection: $priorityType){
                            
                            Text("Urgent").tag(PriorityType.urgent)
                            Text("Ongoing").tag(PriorityType.ongoing)
                            Text("Upcoming").tag(PriorityType.upcoming)
                            Text("Finished").tag(PriorityType.finished)
                            
                        }
                        
                    }
                    DatePicker("Start Date", selection: $selectedStartDate)
                        .padding(.horizontal)
                    
                    DatePicker("Due Date", selection: $selectedEndDate)
                        .padding(.horizontal)
                    
                    Spacer()
                    
                    Spacer()
                    
                    Button("Add Event") {
                        
                    }
                }
            }
        }
    }
}



struct NewEventView_Previews: PreviewProvider {
    static var previews: some View {
        NewEventView()
    }
}
