//
//  NavBar.swift
//  Getter3
//
//  Created by Rohin Joshi on 4/5/23.
//

import SwiftUI

struct NavBar: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct NavBar_Previews: PreviewProvider {
    static var previews: some View {
        NavBar()
    }
}
