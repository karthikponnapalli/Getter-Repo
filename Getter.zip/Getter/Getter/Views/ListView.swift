//
//  ListView.swift
//  Getter
//
//  Created by Rohin Joshi on 4/12/23.
//

import SwiftUI

struct ListView: View {
    var body: some View {
        VStack {
            //heading
            HStack{
                Text(K.GetterName.getterName)
                    .font(.system(size:43, weight: .bold))
                    .padding(.leading, -175)
            }
            //Spacer()
            ScrollView{
                HStack{
                    Button("Urgent"){
                        
                    }
                    .fontWeight(.bold)
                    .font(.title)
                    .frame(width: 151, height: 96, alignment: .leading)
                    .lineSpacing(41)
                    
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color(red: 1, green: 0.28, blue: 0.28))
                        .frame(width: 92, height: 45)
                }
                .padding(.horizontal, 23)
                .padding(.top, 7)
                .padding(.bottom, 8)
                .frame(width: 339, height: 111)
                .background(Color(red: 0.85, green: 0.85, blue: 0.85))
                .cornerRadius(40)
                .frame(width: 339, height: 111)
                
                HStack{
                    Button("Ongoing"){
                        
                    }
                    .fontWeight(.bold)
                    .font(.title)
                    .frame(width: 151, height: 96, alignment: .leading)
                    .lineSpacing(41)
                    
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color(red: 1, green: 0.93, blue: 0.28))
                        .frame(width: 92, height: 45)
                }
                .padding(.horizontal, 23)
                .padding(.top, 7)
                .padding(.bottom, 8)
                .frame(width: 339, height: 111)
                .background(Color(red: 0.85, green: 0.85, blue: 0.85))
                .cornerRadius(40)
                .frame(width: 339, height: 111)
                
                HStack{
                    Button("Upcoming"){
                        
                    }
                    .fontWeight(.bold)
                    .font(.title)
                    .frame(width: 151, height: 96, alignment: .leading)
                    .lineSpacing(41)
                    
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color(red: 0.47, green: 1, blue: 0.28))
                        .frame(width: 92, height: 45)
                }
                .padding(.horizontal, 23)
                .padding(.top, 7)
                .padding(.bottom, 8)
                .frame(width: 339, height: 111)
                .background(Color(red: 0.85, green: 0.85, blue: 0.85))
                .cornerRadius(40)
                .frame(width: 339, height: 111)
                
                HStack{
                    Button("Finished"){
                        
                    }
                    .fontWeight(.bold)
                    .font(.title)
                    .frame(width: 151, height: 96, alignment: .leading)
                    .lineSpacing(41)
                    
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color(red: 0.66, green: 0.39, blue: 1))
                        .frame(width: 92, height: 45)
                }
                .padding(.horizontal, 23)
                .padding(.top, 7)
                .padding(.bottom, 8)
                .frame(width: 339, height: 111)
                .background(Color(red: 0.85, green: 0.85, blue: 0.85))
                .cornerRadius(40)
                .frame(width: 339, height: 111)
            }
            
            Spacer()
        }
    }
}

struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
