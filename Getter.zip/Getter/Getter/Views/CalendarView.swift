//
//  CalendarView.swift
//  Getter
//
//  Created by Rohin Joshi on 4/12/23.
//

import SwiftUI

struct CalendarView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CalendarView_Previews: PreviewProvider {
    static var previews: some View {
        CalendarView()
    }
}
