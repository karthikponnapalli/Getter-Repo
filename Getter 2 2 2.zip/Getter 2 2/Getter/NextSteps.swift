//
//  NextSteps.swift
//  Getter
//
//  Created by Rohin Joshi on 4/17/23.
//

import Foundation

//MVP
//notifications
//reoccuring notifications
//database

//right after MVP
//canvas + other LMS integration

//potential feature:
//run analytics on types of assignments and how long they take
//integrate feedback mechanism
//scehdule optimizations
