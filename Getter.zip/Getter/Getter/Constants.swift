import Foundation

struct K {
    
    struct GetterName {
        static let getterName = "Getter."
    }
    
}
