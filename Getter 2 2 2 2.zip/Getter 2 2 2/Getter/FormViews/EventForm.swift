//
//  EventForm.swift
//  Getter
//
//  Created by Rohin Joshi on 4/24/23.
//

import SwiftUI

struct SheetView: View {
    @Environment(\.dismiss) var dismiss

    var body: some View {
        Button("Press to dismiss") {
            dismiss()
        }
        .font(.title)
        .padding()
        .background(.black)
    }
}

struct EventFormView: View {
    @State private var showingSheet = false

    var body: some View {
        Button{
            showingSheet.toggle()
        } label: {
            Image(systemName: "plus.circle.fill")
        }
        .sheet(isPresented: $showingSheet) {
            NewEventView()
        }
    }
}

struct EventFormView_Previews: PreviewProvider {
    static var previews: some View {
        EventFormView()
    }
}

