//
//  LiftView.swift
//  Getter3
//
//  Created by Rohin Joshi on 4/5/23.
//

import SwiftUI

struct ListView: View {
    var body: some View {
        
        VStack {
            Spacer()
            HStack{
                Button("Urgent"){
                    
                }
                .fontWeight(.bold)
                .font(.title)
                .frame(width: 151, height: 96, alignment: .leading)
                .lineSpacing(41)
                
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(red: 1, green: 0.28, blue: 0.28))
                    .frame(width: 92, height: 45)
            }
            .padding(.horizontal, 23)
            .padding(.top, 7)
            .padding(.bottom, 8)
            .frame(width: 339, height: 111)
            .background(Color(red: 0.85, green: 0.85, blue: 0.85))
            .cornerRadius(40)
            .frame(width: 339, height: 111)
            
            HStack{
                Button("Ongoing"){
                    
                }
                .fontWeight(.bold)
                .font(.title)
                .frame(width: 151, height: 96, alignment: .leading)
                .lineSpacing(41)
                
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(red: 1, green: 0.93, blue: 0.28))
                    .frame(width: 92, height: 45)
            }
            .padding(.horizontal, 23)
            .padding(.top, 7)
            .padding(.bottom, 8)
            .frame(width: 339, height: 111)
            .background(Color(red: 0.85, green: 0.85, blue: 0.85))
            .cornerRadius(40)
            .frame(width: 339, height: 111)
            
            HStack{
                Button("Upcoming"){
                    
                }
                .fontWeight(.bold)
                .font(.title)
                .frame(width: 151, height: 96, alignment: .leading)
                .lineSpacing(41)
                
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(red: 0.47, green: 1, blue: 0.28))
                    .frame(width: 92, height: 45)
            }
            .padding(.horizontal, 23)
            .padding(.top, 7)
            .padding(.bottom, 8)
            .frame(width: 339, height: 111)
            .background(Color(red: 0.85, green: 0.85, blue: 0.85))
            .cornerRadius(40)
            .frame(width: 339, height: 111)
            
            HStack{
                Button("Finished"){
                    
                }
                .fontWeight(.bold)
                .font(.title)
                .frame(width: 151, height: 96, alignment: .leading)
                .lineSpacing(41)
                
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(red: 0.66, green: 0.39, blue: 1))
                    .frame(width: 92, height: 45)
            }
            .padding(.horizontal, 23)
            .padding(.top, 7)
            .padding(.bottom, 8)
            .frame(width: 339, height: 111)
            .background(Color(red: 0.85, green: 0.85, blue: 0.85))
            .cornerRadius(40)
            .frame(width: 339, height: 111)
            
            Spacer()
            
            
            //nav bar
//            ZStack {
//                Text("List ")
//                .font(.title)
//                .lineSpacing(41)
//                .padding(.vertical, 13)
//                .padding(.leading, 29)
//                .padding(.trailing, 275)
//                .offset(x: 347.50, y: -1686)
//                .frame(width: 350, height: 67)
//                .background(Color(red: 0.85, green: 0.85, blue: 0.85))
//                .cornerRadius(80)
//
//            Text("New")
//            .fontWeight(.bold)
//            .font(.title)
//            .frame(width: 160, height: 48, alignment: .leading)
//            .lineSpacing(41)
//            .offset(x: 517, y: -1685.50)
//
//            Text("Calendar")
//            .fontWeight(.bold)
//            .font(.title)
//            .frame(width: 254, height: 47, alignment: .leading)
//            .lineSpacing(41)
//            .offset(x: 413, y: -1685)
//
//            RoundedRectangle(cornerRadius: 80)
//            .fill(Color.black)
//            .offset(x: 223.50, y: -1686)
//            .frame(width: 103, height: 67)
//            }
//            .frame(width: 425, height: 67)
            
            
        }
    }
}

struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
